const { v4: uuidv4 } = require('uuid');
let fs = require('fs')


var methodes={};
let urlDatabase = './database/books_database.json';
methodes.insertBook= async function (newbook)
{


//  newbook.book_id= await newid();
  console.log(newbook);
  newbook = JSON.stringify(newbook);




//append
   fs.readFile(urlDatabase, async function (err, file) {
        if(file)
        {
            var file = file.toString();
        if(file[file.length-1]=="]")
        {
          newbook= ","+newbook+"]";
          console.log(newbook);

          var file = file.substring(0,file.length-1);
          file=file+newbook;
         fs.writeFileSync(urlDatabase, file, function (err) {
           if (err) throw err;
           console.log('File overwrite');
           console.log('The new book was appended to file!');

        });
      }
       else {
            console.log("inesleinsert");
            newbook= "["+newbook+"]";
            console.log(newbook);
             fs.appendFile(urlDatabase, newbook, function (err) {
               if (err) throw err;
               console.log('File created');
               console.log('The new book was appended to file!');
            });


          }


    }



  });
    return "OK";

}

methodes.newid = async function()
{
  console.log("tocreateid");
  var idexist=true;


  var newid="";
  while(idexist==true)
  {
    console.log("dans la boucle");
    var flag = false;
    newid= uuidv4();//create new id
  await fs.readFileSync(urlDatabase, function (err, file) {
    console.log(file);
    if(file && file.length!=0)
    {
    console.log("dans le read");
    var filejson = JSON.parse(file);

    for (var i = 0; i < filejson.length; i++) {

          console.log(filejson[i]);
          if(filejson[i].book_id==newid)
          {
            flag=true;
          }
    }
  }

})

  if(flag!=true)
  {
    idexist=false;
  }
}
    return newid;

};


methodes.updateBook = async function (updatebook)
{
  console.log('inupdatebook');
  var filedb=""
  var file = await fs.readFileSync(urlDatabase,'utf8');
    if(file)
    {
    var filejson = JSON.parse(file);

    for (var i = 0; i < filejson.length; i++) {

          if(filejson[i].book_id==updatebook.book_id)
          {
            filejson[i].book_title =updatebook.book_title
            filejson[i].book_author = updatebook.book_author
            filejson[i].book_edition = updatebook.book_edition
            filejson[i].book_price = updatebook.book_price
            filejson[i].book_synopsis = updatebook.book_synopsis
            filejson[i].book_parution = updatebook.book_parution
            filejson[i].book_category = updatebook.book_category
            filejson[i].book_cover = updatebook.book_cover

          }
    }

    filedb = JSON.stringify(filejson)

  }

console.log(filedb);
await fs.writeFileSync(urlDatabase, filedb, function (err) {
  if (err) throw err;
  console.log('File overwrite');
  console.log('The book was updated!');

});

return "OK";
}

methodes.getAllBooks =  async function ()
{
  var file= await fs.readFileSync(urlDatabase,'utf8');
  return file;
}




methodes.search = async function (search_value)
{
  console.log(search_value);
  var listbookssearched=[];
  var file= await fs.readFileSync(urlDatabase,'utf8');
  var filejson = JSON.parse(file);
  for (var i = 0; i < filejson.length; i++) {
    console.log(JSON.stringify(filejson[i]));

    if(JSON.stringify(filejson[i]).toLowerCase().includes(search_value.toLowerCase()))
    {

      console.log("find a correspondance");
      console.log(filejson[i]);
      listbookssearched.push(filejson[i])
    }


  }

console.log(listbookssearched);
  return listbookssearched;

}

exports.data = methodes;
